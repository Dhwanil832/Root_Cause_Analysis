"""RCA module."""
